"""Review probes for tutorials/florence2_vision_language_colab.ipynb (row 26, review only, CPU, no model).

Run from anywhere:  python run_probes.py <repo_worktree> <workdir>
P0 static checks; P1 carried-cell namespace collisions; P2 default data path (cell 13, real Hub fetch, ~44 MB);
P3 BYOD branch of cell 13 through a shimmed google.colab upload; P4 metric sanity.
No model weights are downloaded; Sections 3 and 5-9 are not executed.
"""
from __future__ import annotations

import ast
import hashlib
import io
import json
import os
import re
import sys
import time
import types
import zipfile
from pathlib import Path

REPO = Path(sys.argv[1]).resolve()
WORK = Path(sys.argv[2]).resolve()
NB_PATH = REPO / "tutorials" / "florence2_vision_language_colab.ipynb"
NB = json.loads(NB_PATH.read_text(encoding="utf-8"))
CELLS = NB["cells"]
SRC = ["".join(c["source"]) for c in CELLS]
RESULTS: dict = {}


def src(i: int) -> str:
    return SRC[i]


# ---------------------------------------------------------------- P0 static
md = "\n".join(SRC[i] for i, c in enumerate(CELLS) if c["cell_type"] == "markdown")
markers = {k: bool(re.search(p, md, re.I)) for k, p in {
    "how_to_use": r"how to use this notebook", "roadmap": r"roadmap", "glossary": r"glossary",
    "check_your_reasoning": r"check your reasoning", "what_to_notice": r"what to notice",
    "conclusion_template": r"conclusion (template|scaffold)", "infrastructure_label": r"infrastructure",
    "intended_learner": r"intended (learner|audience)|this notebook is for", "predict_prompt": r"\bpredict\b(?! )|make a prediction|before you run",
    "troubleshooting": r"troubleshooting", "look_for": r"look for|watch the|expect",
    "run_to_run_variability": r"not bit|bit-reproduc|varies|will vary|run-to-run|nondetermin|non-determin",
}.items()}
code_cells = [i for i, c in enumerate(CELLS) if c["cell_type"] == "code"]
RESULTS["P0_static"] = {
    "nbformat": [NB["nbformat"], NB["nbformat_minor"]],
    "metadata_dimer": NB["metadata"].get("dimer"),
    "n_cells": len(CELLS), "code_cells": code_cells,
    "carried_cell_lines": {i: SRC[i].count("\n") + 1 for i in (5, 7, 9)},
    "persisted_outputs": sum(len(CELLS[i].get("outputs", [])) for i in code_cells),
    "cellView_form_cells": [i for i in code_cells if CELLS[i].get("metadata", {}).get("cellView") == "form"],
    "pip_install_in_kernel": "pip', 'install'" in src(3),
    "restart_instruction_in_install_cell": "Restart the runtime" in src(3),
    "uses_uv": "uv venv" in "\n".join(SRC) or "uv pip" in "\n".join(SRC),
    "env_var_skip_install": "DIMER_NOTEBOOK_CI_PREINSTALLED" in src(3),
    "env_var_documented_in_markdown": "DIMER_NOTEBOOK_CI_PREINSTALLED" in md,
    "guided_markers": markers,
    "byod_location_field": bool(re.search(r"BYOD_(PATH|ZIP|DIR)\s*=", src(13))),
    "byod_uses_files_upload": "files.upload()" in src(13),
    "cell21_hard_asserts": re.findall(r"^assert .*$", src(21), re.M),
    "cell14_mentions_flag": "labelled `flag`" in src(14),
    "cell22_before_adaptation_box_label": re.findall(r"before adaptation caption `[^`]*`, 1 box\(es\) labelled `(\w+)`", src(22)),
    "cell0_byod_min_images_claim": re.findall(r"at least (\w+) images", src(0)),
    "cell1_dataset_bounds_claim": re.findall(r"a dataset needs ([0-9.,]+) records", src(1)),
    "cell24_split_page_advice": "lines cut from the same page share a hand" in src(24),
    "cell0_without_leakage_claim": "split it by line without leakage" in src(0),
    "spec_declared": NB["metadata"]["dimer"].get("notebook_spec"),
    "every_code_cell_compiles": {},
}
for i in code_cells:
    try:
        compile(SRC[i], f"cell{i}", "exec")
        RESULTS["P0_static"]["every_code_cell_compiles"][i] = True
    except SyntaxError as exc:
        RESULTS["P0_static"]["every_code_cell_compiles"][i] = repr(exc)

# ---------------------------------------------------------------- P1 carried-cell namespace collisions
def top_level_assigned(code: str) -> dict:
    out = {}
    for node in ast.parse(code).body:
        targets = []
        if isinstance(node, ast.Assign):
            targets = [t.id for t in node.targets if isinstance(t, ast.Name)]
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            targets = [node.target.id]
        elif isinstance(node, (ast.FunctionDef, ast.ClassDef)):
            targets = [node.name]
        for t in targets:
            out[t] = ast.unparse(node)[:160]
    return out


defs = {i: top_level_assigned(SRC[i]) for i in (5, 7, 9)}
collisions = {}
for a in (5, 7, 9):
    for b in (5, 7, 9):
        if a < b:
            for name in set(defs[a]) & set(defs[b]):
                collisions[name] = {f"cell{a}": defs[a][name], f"cell{b}": defs[b][name]}
os.chdir(WORK)
ns: dict = {"__name__": "__main__"}
os.environ["DIMER_NOTEBOOK_CI_PREINSTALLED"] = "1"
for i in (3, 5, 7, 9):
    exec(compile(SRC[i], f"cell{i}", "exec"), ns)
sys.path.insert(0, str(REPO / "src"))
import florence2_vision_language_pipeline.pipeline as pkg_pipeline  # noqa: E402
from PIL import Image  # noqa: E402

grounding_text = "x" * 600
img = Image.new("RGB", (64, 64), (255, 255, 255))
def try_validate(fn):
    try:
        m = fn(img, "<CAPTION_TO_PHRASE_GROUNDING>", grounding_text)
        return {"accepted": True, "schema_text_input_chars": m["schema"]["text_input_chars"]}
    except Exception as exc:  # noqa: BLE001
        return {"accepted": False, "error": f"{type(exc).__name__}: {exc}"}
RESULTS["P1_namespace"] = {
    "colliding_top_level_names": collisions,
    "notebook_MAX_TEXT_CHARS_after_cell9": ns["MAX_TEXT_CHARS"],
    "package_pipeline_MAX_TEXT_CHARS": pkg_pipeline.MAX_TEXT_CHARS,
    "notebook_INPUT_SCHEMA_text_input_chars": ns["INPUT_SCHEMA"]["text_input_chars"],
    "grounding_600_chars_notebook": try_validate(ns["validate_inputs"]),
    "grounding_600_chars_package": try_validate(pkg_pipeline.validate_inputs),
}
json.dump(RESULTS, open(WORK / "results.partial.json", "w"), indent=1, default=str)

# ---------------------------------------------------------------- P4 metric sanity
recs = [{"id": "a", "text": "abc def"}, {"id": "b", "text": "xy"}]
RESULTS["P4_metrics"] = {
    "empty": {k: ns["ocr_metrics"](["", ""], recs)[k] for k in ("cer", "wer", "exact_match")},
    "overgeneration_cer": ns["ocr_metrics"](["abc def ghijkl mnop", "xy xy xy"], recs)["cer"],
    "perfect": ns["ocr_metrics"](["abc  def", "xy"], recs)["cer"],
}

# ---------------------------------------------------------------- P2 default data path (cell 13)
def run_cell13(use_byod: bool, upload=None, seed=42):
    code = SRC[13].replace("USE_BYOD = False  # @param", f"USE_BYOD = {use_byod}  # @param").replace("SPLIT_SEED = 42  # @param", f"SPLIT_SEED = {seed}  # @param")
    if upload is not None:
        colab = types.ModuleType("google.colab")
        colab.files = types.SimpleNamespace(upload=upload)
        google = types.ModuleType("google")
        google.colab = colab
        sys.modules["google"] = google
        sys.modules["google.colab"] = colab
    out = io.StringIO()
    old = sys.stdout
    sys.stdout = out
    try:
        exec(compile(code, "cell13", "exec"), ns)
        err = None
    except Exception as exc:  # noqa: BLE001
        err = f"{type(exc).__name__}: {exc}"
    finally:
        sys.stdout = old
    return {"error": err, "stdout": out.getvalue()[-3000:]}

t0 = time.perf_counter()
p2 = run_cell13(False)
p2["seconds"] = round(time.perf_counter() - t0, 1)
if p2["error"] is None:
    tr, va, te = ns["train_records"], ns["val_records"], ns["test_records"]
    idnum = lambda r: int(r["id"].rsplit("-", 1)[1])  # noqa: E731
    train_ids = {idnum(r) for r in tr}
    train_texts = {r["text"] for r in tr}
    adj = sum(1 for r in te if (idnum(r) - 1) in train_ids or (idnum(r) + 1) in train_ids)
    rg = {}
    for r in te:
        rg[r["source_row_group"]] = rg.get(r["source_row_group"], 0) + 1
    p2["leakage_proxy"] = {
        "test_lines": len(te),
        "test_lines_with_an_adjacent_corpus_line_in_train": adj,
        "test_row_groups": rg,
        "test_texts_exactly_in_train": sum(1 for r in te if r["text"] in train_texts),
        "test_texts_exactly_in_train_examples": sorted({r["text"] for r in te if r["text"] in train_texts})[:10],
        "val_texts_exactly_in_train": sum(1 for r in va if r["text"] in train_texts),
    }
    p2["outputs"] = sorted(os.listdir("outputs"))
    p2["digests"] = {k: v["digest"] for k, v in ns["dataset_manifests"].items()}
    p2["sample_digest_pin"] = ns["SAMPLE_DIGEST"]
    p2["combined_digest"] = ns["dataset_digest"](tr + va + te)
RESULTS["P2_default_data_path"] = p2
json.dump(RESULTS, open(WORK / "results.partial.json", "w"), indent=1, default=str)

# ---------------------------------------------------------------- P3 BYOD branch of cell 13
from PIL import ImageDraw  # noqa: E402

def line_png(i: int, w: int = 300) -> bytes:
    im = Image.new("RGB", (w, 40), (255, 255, 255))
    ImageDraw.Draw(im).text((5, 10), f"line {i}", fill=(0, 0, 0))
    buf = io.BytesIO()
    im.save(buf, "PNG")
    return buf.getvalue()

def make_zip(members: dict) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        for name, data in members.items():
            z.writestr(name, data)
    return buf.getvalue()

def csv_of(rows):
    return ("file,text\n" + "".join(f"{f},{t}\n" for f, t in rows)).encode()

def simple(n):
    m = {f"l{i}.png": line_png(i) for i in range(n)}
    m["transcripts.csv"] = csv_of([(f"l{i}.png", f"line {i}") for i in range(n)])
    return m

cases = {}
for n in (8, 20, 38, 49, 50):
    payload = make_zip(simple(n))
    cases[f"n={n}"] = run_cell13(True, upload=lambda p=payload: {"lines.zip": p})
    if cases[f"n={n}"]["error"] is None:
        cases[f"n={n}"]["splits"] = ns["disjoint"]
# same basename in two folders -> flattened
m = {"a/x.png": line_png(1), "b/x.png": line_png(2, 500)}
m.update({f"l{i}.png": line_png(i + 10) for i in range(60)})
m["transcripts.csv"] = csv_of([("a/x.png", "first"), ("b/x.png", "second")] + [(f"l{i}.png", f"line {i}") for i in range(60)])
cases["same_basename_two_folders"] = run_cell13(True, upload=lambda p=make_zip(m): {"dup.zip": p})
if cases["same_basename_two_folders"]["error"] is None:
    cases["same_basename_two_folders"]["splits"] = ns["disjoint"]
# duplicate images (same pixels, different files) -> silently dropped?
m = simple(60)
for i in range(10):
    m[f"dup{i}.png"] = line_png(i)
m["transcripts.csv"] = csv_of([(f"l{i}.png", f"line {i}") for i in range(60)] + [(f"dup{i}.png", f"line {i}") for i in range(10)])
r = run_cell13(True, upload=lambda p=make_zip(m): {"dups.zip": p})
if r["error"] is None:
    r["records_in"] = 70
    r["splits"] = ns["disjoint"]
    r["stdout_mentions_dropped"] = bool(re.search(r"drop|duplicate|de-dup", r["stdout"], re.I))
cases["10_duplicate_images_of_70"] = r
m = simple(60); m["notes.txt"] = b"hello"; m["transcripts.csv"] = csv_of([(f"l{i}.png", f"line {i}") for i in range(60)] + [("notes.txt", "x")])
cases["non_image_member"] = run_cell13(True, upload=lambda p=make_zip(m): {"bad.zip": p})
m = simple(60); del m["transcripts.csv"]
cases["missing_transcripts_csv"] = run_cell13(True, upload=lambda p=make_zip(m): {"nocsv.zip": p})
m = simple(60); m["transcripts.csv"] = csv_of([(f"l{i}.png", ("y" * 513) if i == 3 else f"line {i}") for i in range(60)])
cases["text_513_chars"] = run_cell13(True, upload=lambda p=make_zip(m): {"long.zip": p})
cases["not_a_zip"] = run_cell13(True, upload=lambda: {"lines.tar": b"not a zip"})
cases["cancelled_upload"] = run_cell13(True, upload=lambda: {})
for v in cases.values():
    v["stdout"] = v["stdout"][-600:]
RESULTS["P3_byod_cell13"] = cases

json.dump(RESULTS, open(WORK / "results.json", "w", encoding="utf-8"), indent=1, default=str, ensure_ascii=False)
print("done")
